package turing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class TuringMachine {
    // M = (Q, E, T, d, q0, B, F)
    private String B;
    private Map<String, Map<String, List<String>>> d;
    private String q0;
    private Set<String> F;
    private Tape head;
    private Tape tail;
    private Tape current;

    /**
     * Constructs the TuringMachine
     */
    TuringMachine(ArrayList<String> M) {
        B = "";
        d = new TreeMap<String, Map<String, List<String>>>();
        q0 = "";
        F = new TreeSet<String>();

        for (String parts : M) {
            // States
            if (parts.contains("START=")) {
                q0 = parts.substring(6, 8);
            } else if (parts.contains("ACCEPT=")) {
                Collections.addAll(F, parts.substring(7).split("(;)|(,)"));
            } else if (parts.contains("BLANK=")) {
                B = parts.substring(6, 7);
            } else {
                // Transitions
                if (!parts.contains(":")) {
                    parts = parts.substring(0, 2).concat(":λ").concat(parts.substring(2, 6));
                }
                String[] pieces = parts.split("(:)|(,)");
                String from = pieces[0];
                String to = pieces[3];
                if (!d.containsKey(from)) {
                    d.put(from, new TreeMap<String, List<String>>());
                }
                String c = pieces[1];
                c = c.concat("," + pieces[2]);
                if (!d.get(from).containsKey(c)) {
                    d.get(from).put(c, new ArrayList<String>());
                }
                d.get(from).get(c).add(to);
            }
        }

        if (!M.get(0).contains("START=")) {
            q0 = d.keySet().toArray()[0].toString();
        }

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("start:" + q0);
        System.out.println("end:" + F);
        System.out.println("transitions:" + d);

    }

    /**
     * Creates a new char String to the Tape node
     */
    public void insertAtEnd(String t) {
        Tape add = new Tape(t);
        Tape current = tail;
        if (head == null) {
            head = add;
        }
        if (current != null) {
            add.prev = current;
            current.next = add;
        } else {
            add.prev = null;
        }
        add.next = null;
        tail = add;
    }

    /**
     * Moves the Tape right(R) or left(L)
     */
    public void moveTape(String m) {
        if (m.equals("R")) {
            current = current.next;
        } else {
            current = current.prev;
        }
    }

    /**
     * Changes the value of the char String on the Tape
     */
    public void changeValueOnTape(String value) {
        current.letter = value;
    }

    /**
     * Checks to see if the state contains the transition value. Returns true if it
     * does and false if it is does not.
     */
    public boolean doesContain(Set<String> set) {
        for (String s : set) {
            String[] split = s.split("(->)|(,)");
            if (split[0].equals(current.letter)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets all the transition values (ex: if a|b,R returns [a, b, R])
     */
    public List<String> values(Set<String> set) {
        List<String> collect = new ArrayList<String>();
        for (String s : set) {
            String[] split = s.split("(->)|(,)");
            if (split[0].equals(current.letter)) {
                for (String sp : split) {
                    collect.add(sp);
                }
            }
        }
        return collect;
    }

    /**
     * Gets all possible states containing the seen value of the char String (ex: if
     * a|b,R then the seen value is a)
     */
    public Set<String> getStates(Set<String> set, String state) {
        Set<String> collect = new TreeSet<String>();
        for (String s : set) {
            String[] split = s.split("(->)|(,)");
            if (split[0].equals(current.letter)) {
                collect.addAll(d.get(state).get(s));
            }
        }
        return collect;
    }

    /**
     * Returns whether or not the Turing Machine accepts the string
     */
    public boolean accepted(String s) {
        head = null;
        tail = null;
        current = null;
        s = B + s + B;
        String[] splitting = s.split("");
        for (String c : splitting) {
            insertAtEnd(c);
        }
        current = head.next;
        Set<String> previousStates = new TreeSet<String>();
        previousStates.add(q0);
        while (current != null) {
            Set<String> nextStates = new TreeSet<String>();
            for (String state : previousStates) {
                if (d.get(state) == null) {
                    return false;
                }
                Set<String> collect = d.get(state).keySet();
                if (doesContain(collect)) {
                    nextStates = getStates(collect, state);
                    List<String> values = values(collect);
                    changeValueOnTape(values.get(1));
                    moveTape(values.get(2));
                } else {
                    if (current.next == null && F.contains(state)) {
                        return true;
                    }
                    return false;
                }
            }
            if (nextStates.isEmpty())
                return false;
            previousStates = nextStates;
        }
        for (String state : previousStates) {
            if (F.contains(state))
                return true;
        }
        return false;
    }

    /**
     * Constructs the Tape node
     */
    private class Tape {
        Tape next;
        Tape prev;
        String letter;

        Tape(String l) {
            letter = l;
        }
    }

    public static void main(String[] args) {
        System.out.println("Turing Machine Simulator");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("The string you entered is: " + args[0]);
        String stringy = args[0];
        ArrayList<String> arrli = new ArrayList<String>();
        System.out.println("Enter a description of an NFA:");
        System.out.println("Press Control + D when you are done.");
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            String myString = scanner.next();
            if (myString.contains(";")) {
                for (String s : myString.split(";")) {
                    arrli.add(s);
                }
            } else {
                arrli.add(myString);
            }
        }
        TuringMachine tm = new TuringMachine(arrli);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        if (tm.accepted(stringy)) {
            System.out.println(stringy + " is an accepted string in this Turing Machine.");
        } else {
            System.out.println(stringy + " is not an accepted string in this Turing Machine.");
        }
        scanner.close();
    }
}
