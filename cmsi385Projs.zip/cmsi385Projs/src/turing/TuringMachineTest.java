package turing;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class TuringMachineTest {

    @Test
    public void test01() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("START=q0");
        arrli.add("ACCEPT=q2");
        arrli.add("BLANK=B");
        arrli.add("q0:a->a,R,q1");
        arrli.add("q1:b->b,R,q2");
        arrli.add("q2:a->a,R,q2");
        TuringMachine h = new TuringMachine(arrli);
        assertTrue(h.accepted("abaa"));
        assertTrue(h.accepted("abaaaaaa"));
        assertFalse(h.accepted("baaaaaa"));
        assertFalse(h.accepted("dgb"));
    }

    @Test
    public void test02() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("START=q0");
        arrli.add("ACCEPT=q2,q1");
        arrli.add("BLANK=B");
        arrli.add("q0:a->b,R,q1");
        arrli.add("q1:a->c,L,q2");
        arrli.add("q0:b->b,R,q0");
        TuringMachine h = new TuringMachine(arrli);
        assertTrue(h.accepted("bba"));
        assertFalse(h.accepted("aabc"));
        assertTrue(h.accepted("bbbbbba"));
    }

    @Test
    public void test03() {
        // L = {# of a's = # of b's}
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("START=q0");
        arrli.add("ACCEPT=q4");
        arrli.add("BLANK=B");
        arrli.add("q0:x->x,R,q0");
        arrli.add("q0:y->y,R,q0");
        arrli.add("q0:a->x,R,q1");
        arrli.add("q0:B->B,R,q4");
        arrli.add("q1:a->a,R,q1");
        arrli.add("q1:x->x,R,q1");
        arrli.add("q1:y->y,R,q1");
        arrli.add("q0:b->y,R,q2");
        arrli.add("q2:b->b,R,q2");
        arrli.add("q2:x->x,R,q2");
        arrli.add("q2:y->y,R,q2");
        arrli.add("q1:b->y,L,q3");
        arrli.add("q2:a->x,L,q3");
        arrli.add("q3:a->a,L,q3");
        arrli.add("q3:b->b,L,q3");
        arrli.add("q3:x->x,L,q3");
        arrli.add("q3:y->y,L,q3");
        arrli.add("q3:B->B,R,q0");
        TuringMachine h = new TuringMachine(arrli);
        assertTrue(h.accepted("aabb"));
        assertTrue(h.accepted("abbabbaa"));
        assertFalse(h.accepted("aab"));
        assertFalse(h.accepted("hsg"));
    }

    @Test
    public void test04() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("START=q0");
        arrli.add("ACCEPT=q2");
        arrli.add("BLANK=B");
        arrli.add("q0:0->x,R,q0");
        arrli.add("q0:0->y,R,q1");
        arrli.add("q0:B->B,R,q2");
        arrli.add("q1:1->y,R,q1");
        arrli.add("q1:B->B,R,q2");
        TuringMachine h = new TuringMachine(arrli);
        assertTrue(h.accepted("001"));
    }

    @Test
    public void test05() {
        // L = {0^n1^n: n>=1}
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("ACCEPT=q4;");
        arrli.add("BLANK=B");
        arrli.add("q0:0->x,R,q1");
        arrli.add("q0:y->y,R,q3");
        arrli.add("q1:y->y,R,q1");
        arrli.add("q1:0->0,R,q1");
        arrli.add("q1:1->y,L,q2");
        arrli.add("q2:y->y,L,q2");
        arrli.add("q2:0->0,L,q2");
        arrli.add("q2:x->x,R,q0");
        arrli.add("q3:y->y,R,q3");
        arrli.add("q3:B->B,R,q4");
        TuringMachine h = new TuringMachine(arrli);
        assertTrue(h.accepted("0011"));
        assertTrue(h.accepted("000111"));
        assertTrue(h.accepted("01"));
        assertTrue(h.accepted("00000000001111111111"));
        assertFalse(h.accepted("001"));
        assertFalse(h.accepted("011"));

    }
}
