package nfa;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class Tests {

    @Test
    public void test01() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("START=q0;");
        arrli.add("ACCEPT=q2,q1");
        arrli.add("q0:a->q1");
        arrli.add("q0:a->q2");
        arrli.add("q0->q2");
        arrli.add("q0:a->q0");
        NFA h = new NFA(arrli);
        assertEquals(true, h.accepted("a"));
        assertEquals(true, h.accepted("λ"));
        assertEquals(false, h.accepted("aaab"));
        assertEquals(false, h.accepted("ab"));
        assertEquals(false, h.accepted("abc"));
    }

    @Test
    public void test02() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("ACCEPT=q0");
        arrli.add("q0->q1");
        arrli.add("q0->q2");
        arrli.add("q1->q2");
        arrli.add("q2->q3");
        arrli.add("q3:a->q0");
        NFA h = new NFA(arrli);
        assertEquals(true, h.accepted("a"));
        assertEquals(false, h.accepted("λ"));
        assertEquals(false, h.accepted("b"));
        assertEquals(false, h.accepted("bcdsse"));
        assertEquals(false, h.accepted("0"));
    }

    @Test
    public void test03() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("START=q0;");
        arrli.add("ACCEPT=q3,q4");
        arrli.add("q0->q1");
        arrli.add("q1:a->q2");
        arrli.add("q1:a->q4");
        arrli.add("q1->q0");
        arrli.add("q2->q3");
        arrli.add("q2->q1");
        NFA h = new NFA(arrli);
        assertEquals(true, h.accepted("a"));
        assertEquals(false, h.accepted("b"));
        assertEquals(false, h.accepted("bsjahkfj"));
        assertEquals(false, h.accepted("0"));
    }

    @Test
    public void test04() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("START=q0;");
        arrli.add("ACCEPT=q0");
        arrli.add("q0:0->q0");
        arrli.add("q0:1->q1");
        arrli.add("q1:0->q1");
        arrli.add("q1:1->q1");
        arrli.add("q1:0->q2");
        arrli.add("q2:0->q0");
        NFA h = new NFA(arrli);
        assertEquals(true, h.accepted("001100"));
        assertEquals(true, h.accepted("01100"));
        assertEquals(true, h.accepted("0111111100"));
        assertEquals(true, h.accepted("00000000"));
        assertEquals(false, h.accepted("11"));
        assertEquals(false, h.accepted("λ"));
    }

    @Test
    public void test05() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("ACCEPT=q0,q4,q5");
        arrli.add("q0->q1");
        arrli.add("q1->q2");
        arrli.add("q1->q3");
        arrli.add("q2:0->q4");
        arrli.add("q3:1->q5");
        arrli.add("q4->q0");
        arrli.add("q5->q0");
        NFA h = new NFA(arrli);
        assertEquals(true, h.accepted("0"));
        assertEquals(true, h.accepted("1"));
        assertEquals(true, h.accepted("1100010101011"));
        assertEquals(false, h.accepted("λ"));
    }

    @Test
    public void test06() {
        ArrayList<String> arrli = new ArrayList<String>();
        arrli.add("ACCEPT=q1,q3");
        arrli.add("q1:a->q1");
        arrli.add("q1:a->q2");
        arrli.add("q1:b->q2");
        arrli.add("q1:c->q2");
        arrli.add("q1:c->q3");
        arrli.add("q2:b->q1");
        arrli.add("q2:b->q3");
        arrli.add("q2:c->q1");
        arrli.add("q3:a->q3");
        arrli.add("q3:b->q1");
        arrli.add("q3:b->q2");
        arrli.add("q3:c->q1");
        arrli.add("q3:c->q2");
        arrli.add("q3:c->q3");
        NFA h = new NFA(arrli);
        assertEquals(true, h.accepted("abbacbcab"));
    }

}
