package nfa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class NFA {
    // M = (Q, E, d, q0, F)
    private Map<String, Map<String, List<String>>> d;
    private String q0;
    private Set<String> F;

    /**
     * Constructs the NFA
     */
    NFA(ArrayList<String> M) {
        d = new TreeMap<String, Map<String, List<String>>>();
        q0 = "";
        F = new TreeSet<String>();

        for (String parts : M) {
            // States
            if (parts.contains("START=")) {
                q0 = parts.substring(6, 8);
            } else if (parts.contains("ACCEPT=")) {
                Collections.addAll(F, parts.substring(7).split(","));
            } else {
                // Transitions
                if (!parts.contains(":")) {
                    parts = parts.substring(0, 2).concat(":λ").concat(parts.substring(2, 6));
                }
                String[] pieces = parts.split("(:)|(->)");
                String from = pieces[0];
                String to = pieces[2];
                if (!d.containsKey(from)) {
                    d.put(from, new TreeMap<String, List<String>>());
                }
                String c = pieces[1];
                if (!d.get(from).containsKey(c)) {
                    d.get(from).put(c, new ArrayList<String>());
                }
                d.get(from).get(c).add(to);
            }
        }

        if (!M.get(0).contains("START=")) {
            q0 = d.keySet().toArray()[0].toString();
        }

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("start:" + q0);
        System.out.println("end:" + F);
        System.out.println("transitions:" + d);

    }

    /**
     * Returns whether or not the NFA accepts the string
     */
    public boolean accepted(String s) {
        Set<String> previousStates = new TreeSet<String>();
        previousStates.add(q0);
        String[] c = s.split("");
        for (int i = 0; i < s.length(); i++) {
            Set<String> nextStates = new TreeSet<String>();
            for (String state : previousStates) {
                if (d.get(state) == null) {
                    nextStates.remove(state);
                } else {
                    if (d.get(state).containsKey(c[i]))
                        nextStates.addAll(d.get(state).get(c[i]));
                    if (d.get(state).containsKey("λ"))
                        nextStates = skipLambda(state, previousStates, nextStates, c[i]);
                }
            }
            if (nextStates.isEmpty())
                return false;
            previousStates = nextStates;
        }
        for (String state : previousStates) {
            if (F.contains(state))
                return true;
        }
        return false;
    }

    /**
     * Helper method to skip lambda values - since they are empty strings
     */

    public Set<String> skipLambda(String state, Set<String> previousStates, Set<String> nextStates, String c) {
        for (String ns : d.get(state).get("λ")) {
            if (d.get(ns) == null) {
                nextStates.remove(state);
            } else if (d.get(ns).containsKey(c)) {
                nextStates.addAll(d.get(ns).get(c));
                break;
            } else if (previousStates.contains(ns)) {
                break;
            } else if (d.get(ns).containsKey("λ")) {
                skipLambda(ns, previousStates, nextStates, c);
            }
        }
        return nextStates;

    }

    public static void main(String[] args) {
        System.out.println("NFA Simulator");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("The string you entered is: " + args[0]);
        String stringy = args[0];
        ArrayList<String> arrli = new ArrayList<String>();
        System.out.println("Enter a description of an NFA:");
        System.out.println("Press Command + D on OS X or Control + D on Windows when you are done.");
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            String myString = scanner.next();
            arrli.add(myString);
        }
        NFA nfa = new NFA(arrli);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        if (nfa.accepted(stringy)) {
            System.out.println(stringy + " is an accepted string in this NFA.");
        } else {
            System.out.println(stringy + " is not an accepted string in this NFA.");
        }
        scanner.close();
    }
}
